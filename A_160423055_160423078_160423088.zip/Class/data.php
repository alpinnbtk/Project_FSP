<?php

define("SERVER_NAME", "localhost");
define("DB_NAME", "fullstack");
define("USER_NAME", "root");
define("PASSWORD", "");
